# frozen_string_literal: true
class ERB
  VERSION = '4.0.4'
  private_constant :VERSION
end
