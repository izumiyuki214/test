# frozen_string_literal: true

require 'digest.so'
