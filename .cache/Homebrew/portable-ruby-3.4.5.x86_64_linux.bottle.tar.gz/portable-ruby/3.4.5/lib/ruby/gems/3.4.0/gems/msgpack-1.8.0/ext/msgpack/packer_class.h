/*
 * MessagePack for Ruby
 *
 * Copyright (C) 2008-2013 Sadayuki Furuhashi
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
#ifndef MSGPACK_RUBY_PACKER_CLASS_H__
#define MSGPACK_RUBY_PACKER_CLASS_H__

#include "packer.h"

extern VALUE cMessagePack_Packer;

extern const rb_data_type_t packer_data_type;

static inline msgpack_packer_t *MessagePack_Packer_get(VALUE object) {
    msgpack_packer_t *packer;
    TypedData_Get_Struct(object, msgpack_packer_t, &packer_data_type, packer);
    if (!packer) {
        rb_raise(rb_eArgError, "Uninitialized Packer object");
    }
    return packer;
}

void MessagePack_Packer_module_init(VALUE mMessagePack);

VALUE MessagePack_Packer_alloc(VALUE klass);

VALUE MessagePack_Packer_initialize(int argc, VALUE* argv, VALUE self);

#endif

