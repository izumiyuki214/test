# frozen_string_literal: true

module Bootsnap
  VERSION = "1.18.6"
end
