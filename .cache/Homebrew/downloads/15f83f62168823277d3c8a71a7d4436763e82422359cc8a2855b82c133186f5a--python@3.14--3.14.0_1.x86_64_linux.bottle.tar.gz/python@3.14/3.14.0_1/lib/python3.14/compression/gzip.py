import gzip
__doc__ = gzip.__doc__
del gzip

from gzip import *
