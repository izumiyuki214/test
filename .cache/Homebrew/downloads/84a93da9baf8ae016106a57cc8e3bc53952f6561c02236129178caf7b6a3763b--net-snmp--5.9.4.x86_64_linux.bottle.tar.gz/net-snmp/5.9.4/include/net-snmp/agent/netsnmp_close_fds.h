#ifndef netsnmp_close_fds_h_INCLUDED
#define netsnmp_close_fds_h_INCLUDED

extern void netsnmp_close_fds(int fd);

#endif /* netsnmp_close_fds_h_INCLUDED */
