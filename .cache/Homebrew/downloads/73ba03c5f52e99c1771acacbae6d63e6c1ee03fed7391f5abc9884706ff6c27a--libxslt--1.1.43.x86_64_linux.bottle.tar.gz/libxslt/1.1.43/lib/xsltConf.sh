#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L@@HOMEBREW_CELLAR@@/libxslt/1.1.43/lib"
XSLT_LIBS="-lxslt -L@@HOMEBREW_PREFIX@@/opt/libxml2/lib -lxml2 "
XSLT_PRIVATE_LIBS="-lm"
XSLT_INCLUDEDIR="-I@@HOMEBREW_CELLAR@@/libxslt/1.1.43/include"
MODULE_VERSION="xslt-1.1.43"
